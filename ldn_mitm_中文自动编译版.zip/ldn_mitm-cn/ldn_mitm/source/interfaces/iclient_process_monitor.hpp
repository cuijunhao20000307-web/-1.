/*
 * Copyright (c) 2018 Atmosphère-NX
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#pragma once
#include <stratosphere.hpp>

#define AMS_ICLIENT_PROCESS_MONITOR_INTERFACE(C, H) \
    AMS_SF_METHOD_INFO(C, H, 0, Result, RegisterClient, (const ams::sf::ClientProcessId &client_process_id), (client_process_id))

AMS_SF_DEFINE_INTERFACE(ams::mitm::ldn, IClientProcessMonitorInterface, AMS_ICLIENT_PROCESS_MONITOR_INTERFACE, 0x4EF8C3F3)
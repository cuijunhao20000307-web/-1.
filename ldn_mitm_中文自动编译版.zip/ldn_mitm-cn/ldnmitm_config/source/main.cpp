#include <stdio.h>
#include <stdlib.h>
#include <switch.h>
#include <string.h>
#include "ldn.h"

#define MODULEID 0x233
static Service g_ldnSrv;
static LdnMitmConfigService g_ldnConfig;

Result saveLogToFile() {
    Result rc = 0;
    rc = ldnMitmSaveLogToFile(&g_ldnConfig);
    if (R_FAILED(rc)) {
        printf("保存日志失败：%x\n", rc);
        return rc;
    }

    return rc;
}

void cleanup() {
    serviceClose(&g_ldnSrv);
    serviceClose(&g_ldnConfig.s);
}

void die(const char *reason) {
    
    printf("致命错误：%s\n按任意键退出。", reason);
    padConfigureInput(8, HidNpadStyleSet_NpadStandard);

    PadState pad;
    padInitializeAny(&pad);

    while(appletMainLoop()) {
        padUpdate(&pad);
        u64 kDown = padGetButtonsDown(&pad);
        if (kDown) {
            break;
        }
        consoleUpdate(NULL);
    }
    consoleExit(NULL);
    cleanup();
    exit(1);
}

void printHeader() {
    char version[32];
    Result rc = ldnMitmGetVersion(&g_ldnConfig, version);
    if (R_FAILED(rc)) {
        strcpy(version, "读取失败");
    }

    printf("    ldnmitm_config " VERSION_STRING "\n          ldn_mitm %s\n\n", version);
}

const char * getOnOff(u32 enabled) {
    if (enabled) {
        return CONSOLE_GREEN "开启" CONSOLE_RESET;
    } else {
        return CONSOLE_RED "关闭" CONSOLE_RESET;
    }
}

void printStatus() {
    u32 enabled;
    Result rc = ldnMitmGetLogging(&g_ldnConfig, &enabled);
    if (R_FAILED(rc)) {
        die("无法读取日志状态");
    }
    printf("日志记录（X）：%s\n", getOnOff(enabled));

    rc = ldnMitmGetEnabled(&g_ldnConfig, &enabled);
    if (R_FAILED(rc)) {
        die("无法读取启用状态");
    }
    printf("ldn_mitm（Y）：%s\n", getOnOff(enabled));

    putchar('\n');
    puts("按 X：切换日志记录（sd:/ldn_mitm.log）");
    puts("按 Y：启用或关闭 ldn_mitm");
    puts("按 +：退出");
}

void reprint() {
    consoleClear();

    printHeader();
    printStatus();
}

void toggleLogging() {
    u32 enabled;
    Result rc = ldnMitmGetLogging(&g_ldnConfig, &enabled);
    if (R_FAILED(rc)) {
        die("无法读取日志状态");
    }
    rc = ldnMitmSetLogging(&g_ldnConfig, !enabled);
    if (R_FAILED(rc)) {
        die("无法修改日志状态");
    }
}

void toggleEnabled() {
    u32 enabled;
    Result rc = ldnMitmGetEnabled(&g_ldnConfig, &enabled);
    if (R_FAILED(rc)) {
        die("无法读取启用状态");
    }
    rc = ldnMitmSetEnabled(&g_ldnConfig, !enabled);
    if (R_FAILED(rc)) {
        die("无法修改启用状态");
    }
}

void getLdnMitmConfig() {
    Result rc = ldnMitmGetConfig(&g_ldnConfig);
    if (R_SUCCEEDED(rc)) {
        return;
    }

    Result namedRc = rc;
    rc = smGetService(&g_ldnSrv, "ldn:u");
    if (R_FAILED(rc)) {
        die("无法获取 ldn:u 服务");
    }
    rc = ldnMitmGetConfigFromService(&g_ldnSrv, &g_ldnConfig);
    if (R_SUCCEEDED(rc)) {
        return;
    }

    printf("错误代码：0x%x, 0x%x\n", rc, namedRc);
    die("ldn_mitm 未加载");
}

int main(int argc, char* argv[]) {
    consoleInit(NULL);

    getLdnMitmConfig();
    padConfigureInput(8, HidNpadStyleSet_NpadStandard);

    PadState pad;
    padInitializeAny(&pad);

    u32 kDownOld = 0;

    reprint();
    while(appletMainLoop()) {
        padUpdate(&pad);
        u64 kDown = padGetButtonsDown(&pad);

        if (kDown & HidNpadButton_Plus) {
            break;
        }
        if(kDown != kDownOld)
        {
            if (kDown & HidNpadButton_StickL) {
                Result rc = saveLogToFile();
                if (R_SUCCEEDED(rc)) {
                    puts("日志导出完成");
                }
            }

            if (kDown & HidNpadButton_X) {
                toggleLogging();
                reprint();
            }

            if (kDown & HidNpadButton_Y) {
                toggleEnabled();
                reprint();
            }
        }

        kDownOld = kDown;

        consoleUpdate(NULL);
    }

    consoleExit(NULL);
    cleanup();
    return 0;
}
